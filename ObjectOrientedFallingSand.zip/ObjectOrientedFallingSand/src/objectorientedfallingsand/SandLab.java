package objectorientedfallingsand;

import java.awt.*;
import java.util.*;

// Question about probability in step()

public class SandLab
{
    //do not add any more fields
    private Particle[][] grid;
    private SandDisplay display;
    public static final int ROWS = 120;
    public static final int COLUMNS = 80;

    public static void main(String[] args)
    {
        SandLab lab = new SandLab(ROWS, COLUMNS);
        lab.run();
    }

    public SandLab(int numRows, int numCols)
    {
        // make sure to update array length
        Particle[] particles = new Particle[13];// oh hey, an array
        grid = new Particle[numRows][numCols];
        
        Movement left = new Movement(0,-1);
        Movement right = new Movement(0,1);
        Movement down = new Movement(1,0);
        Movement up = new Movement(-1,0);
        Movement nowhere = new Movement(0,0);
        // could have diagonals too with (1,1) or (-1,-1) etc.
        
        Particle empty = new Particle();
        empty.setName("Empty");
        empty.setColor(new Color (0,0,0));
        
        Particle metal = new Particle();
        metal.setName("Metal");
        metal.setColor(new Color (95, 93, 99));
        
        Particle sand = new Particle();
        sand.setName("Sand");
        sand.setColor(new Color (255,255,128));
        sand.addMovement(down);
        
        Particle water = new Particle();
        water.setName("Water");
        water.setColor(new Color (25,178,255));
        // slow down for testing purposes
        //for (int i = 0; i < 80; i++){water.addMovement(nowhere);}
        water.addMovement(left);
        water.addMovement(right);
        water.addMovement(down);
        
        Particle dirt = new Particle();
        dirt.setName("Dirt");
        dirt.setColor(new Color (161,83,55));
        dirt.addMovement(down);
        for (int i = 0; i < 2; i++){dirt.addMovement(nowhere);}
        // slow down falling rate; make it feel just a bit clumpier
        
        Particle mud = new Particle();
        mud.setName("Mud");
        mud.setColor(new Color (77,13,0));
        mud.addMovement(down);
        for (int i = 0; i < 5; i++){mud.addMovement(nowhere);}// slow down falling rate; make it feel clumpier
        
        Particle blueConfetti = new Particle();
        blueConfetti.setName("Confetti");
        blueConfetti.setColor(new Color (0,0,255));
        blueConfetti.addMovement(left);
        blueConfetti.addMovement(right);
        blueConfetti.addMovement(up);
        for (int i = 0; i < 2; i++){blueConfetti.addMovement(nowhere);} // more fluttery
        
        Particle yellowConfetti = new Particle();
        yellowConfetti.setName("Yellow Confetti");
        yellowConfetti.setColor(new Color (255,255,0));
        yellowConfetti.addMovement(left);
        yellowConfetti.addMovement(right);
        yellowConfetti.addMovement(down);
        for (int i = 0; i < 2; i++){yellowConfetti.addMovement(nowhere);} // more fluttery
        
        Particle seed = new Particle();
        seed.setName("Seed");
        seed.setColor(new Color (105,63,27));
        seed.addMovement(down);
        for (int i = 0; i < 40; i++){seed.addMovement(nowhere);}// stunt falling rate with nowhere movements
        
        // nowhere movement rates ordinarily 100
        Particle plant = new Particle();
        plant.setName("Plant");
        plant.setColor(new Color (4,202,4));
        plant.addMovement(left);
        plant.addMovement(right);
        for (int i = 0; i < 2; i++){plant.addMovement(up);}// adjust rate of growing upwards
        for (int i = 0; i < 200; i++){plant.addMovement(nowhere);}// stunt growing rate with nowhere movements
        
        Particle stem = new Particle();
        stem.setName("Stem");
        stem.setColor(new Color (65, 141, 35));
        stem.addMovement(up);
        for (int i = 0; i < 200; i++){stem.addMovement(nowhere);}// stunt growing rate with nowhere movements
        
        // special!
            // this doesn't mean much now
        SpecialParticle branch = new SpecialParticle();
        branch.setName("Branch");
        branch.setColor(new Color (65, 141, 35)); 
        //branch.setColor(new Color (255, 0, 0)); // different color for testing purposes; ordinarily same as stemWW
        branch.addMovement(left); // would like it to choose left OR right and stick with it but this may have to do
        branch.addMovement(right);
        for (int i = 0; i < 200; i++){branch.addMovement(nowhere);}// stunt growing rate with nowhere movements
        
        SpecialParticle grownTip = new SpecialParticle();
        grownTip.setName("Tip");
        grownTip.setColor(new Color (65, 141, 35));
        //grownTip.setColor(new Color (255, 0, 0)); // different color for testing purposes; ordinarily same as stem
        // no movement; meant to stop growth
        
        // if I can figure out sticking with one direction for either branch or wind I should be able to figure it out for the other
        Particle wind = new Particle(); 
        wind.setName("Wind");
        wind.setColor(new Color (38, 39, 39)); // very dark gray
        wind.addMovement(left); // would like it to choose left OR right and stick with it but this may have to do
        wind.addMovement(up);
        wind.addMovement(down);
        
        Particle fire = new Particle();
        fire.setName("Fire");
        fire.setColor(new Color(255, 122, 0));
        fire.addMovement(left);
        fire.addMovement(right);
        fire.addMovement(down);
        
        Particle ash = new Particle();
        ash.setName("Ash");
        ash.setColor(new Color (134, 131, 123));
        ash.addMovement(down);
        for (int i = 0; i < 2; i++){branch.addMovement(nowhere);} // falls a little clumpy
        
        Particle steam = new Particle();
        steam.setName("Steam");
        steam.setColor(new Color (240, 241, 252));
        steam.addMovement(left);
        steam.addMovement(right);
        steam.addMovement(up);
        
        Particle clay = new Particle();
        clay.setName("Clay");
        //rgb(129, 124, 112)
        clay.setColor(new Color (113, 107, 89)); // darker than ash
        clay.addMovement(down);
        for (int i = 0; i < 5; i++){branch.addMovement(nowhere);} // clumpy like mud
        
        // future plans:
            // coal, smoke, rain cloud, storm cloud (lightning + rain), 
            // lightning, glass (lightning + sand = glass)
        // remember to update array size when adding new particles
        particles[0] = empty;
        particles[1] = metal;
        particles[2] = sand;
        particles[3] = water;
        particles[4] = dirt;
        particles[5] = mud;
        particles[6] = blueConfetti; // don't include yellow confetti; user can only toss up the blue stuff
        particles[7] = seed; // can plant seeds but not directly place plant, stem, or branch
        particles[8] = wind;
        particles[9] = fire;
        particles[10] = ash;
        particles[11] = clay;
        particles[12] = steam;
        
        // update array length accordingly if you'd like to test
        /*
        particles[13] = plant;
        particles[14] = stem;
        particles[15] = branch;
        */
        
        Arrays.sort(particles);
        // relationships; have to set up after particles
        // no relationship; simply sits
            // empty, metal
        // sand
        Relationship sandWithEmpty = new Relationship(empty, empty, sand); // falls down
        sand.addRelationship(sandWithEmpty);
        Relationship sandWithWater = new Relationship(water, water, sand); // swaps
        sand.addRelationship(sandWithWater);
        // water
        Relationship waterWithEmpty = new Relationship(empty, empty, water); // sprays down
        water.addRelationship(waterWithEmpty);
        Relationship waterWithDirt = new Relationship(dirt, mud, mud); // irrigates the first layer or two of dirt
        water.addRelationship(waterWithDirt);
        Relationship waterWithAsh = new Relationship(ash, clay, water); // turns ash into clay
        water.addRelationship(waterWithAsh);
        
        // dirt
        Relationship dirtWithEmpty = new Relationship(empty, empty, dirt); // falls down
        dirt.addRelationship(dirtWithEmpty);
        Relationship dirtWithWater = new Relationship(water, water, dirt); // falls down
        dirt.addRelationship(dirtWithWater);
        // mud
        Relationship mudWithEmpty = new Relationship(empty, empty, mud); // falls down
        mud.addRelationship(mudWithEmpty);
        Relationship mudWithWater = new Relationship(water, water, mud);// sinks through water
        mud.addRelationship(mudWithWater);
        // confetti
        // blue
            // how do I make it turn into yellow when it hits the top? look in location at step()
        Relationship blueConfettiWithEmpty = new Relationship(empty, empty, blueConfetti); // sprays up
        blueConfetti.addRelationship(blueConfettiWithEmpty);
        // turns into yellow when it crashes into itself
        Relationship blueConfettiWithBlueConfetti = new Relationship(blueConfetti, yellowConfetti, blueConfetti);
        blueConfetti.addRelationship(blueConfettiWithBlueConfetti);
        // yellow
        Relationship yellowConfettiWithEmpty = new Relationship(empty, empty, yellowConfetti); // sprays down
        yellowConfetti.addRelationship(yellowConfettiWithEmpty);
        Relationship yellowConfettiWithYellowConfetti = new Relationship(yellowConfetti, empty, yellowConfetti);
        yellowConfetti.addRelationship(yellowConfettiWithYellowConfetti);
        
        // fire can only spread to burnable things
            // fire turns plants into ash (after spreading if it can) (later, fire also turns coal into ash, but more slowly); this produces smoke
        Relationship fireWithEmpty = new Relationship(empty, empty, fire); // falls down
        fire.addRelationship(fireWithEmpty);
            // but sticks to burnable particles
        Relationship fireWithPlant = new Relationship(plant, grownTip, fire); // turns plant into grownTip
        fire.addRelationship(fireWithPlant);
        Relationship fireWithTip = new Relationship(grownTip, ash, fire); // turns grownTip into ash
        fire.addRelationship(fireWithTip);
        // these two together should help slow down burning a plant
            // could I add dummy relationships to slow it down like I do with movements?
        Relationship fireWithBranch = new Relationship(branch, ash, fire); // turns branch into ash
        fire.addRelationship(fireWithBranch);
        Relationship fireWithSeed = new Relationship(seed, ash, fire); // turns seed into ash
        fire.addRelationship(fireWithSeed);
        // if it has nothing to burn it will extinguish
        Relationship fireWithFire = new Relationship(fire, empty, fire); // turns fire into empty
        fire.addRelationship(fireWithFire);
        // water will also extinguish fire
        Relationship fireWithWater = new Relationship(water, steam, fire); // turns fire into steam
        fire.addRelationship(fireWithWater);
            // but the fire doesn't disappear if it's one its own, which means that a single fire particle
            //      will turn infinitely many water particles into steam
        
        // ash
        Relationship ashWithEmpty = new Relationship(empty, empty, ash); // falls down
        ash.addRelationship(ashWithEmpty);
        // wind
        Relationship windWithEmpty = new Relationship(empty, empty, wind); // blows left
        wind.addRelationship(windWithEmpty);
        Relationship windWithWind = new Relationship(wind, empty, wind); // vanishes
        wind.addRelationship(windWithWind);
        Relationship windWithAsh = new Relationship(ash, wind, wind); // blows ash away
        wind.addRelationship(windWithAsh);
        Relationship windWithSteam = new Relationship(steam, wind, wind); // blows steam away
            // IF you have real good timing, that is
        wind.addRelationship(windWithSteam);
        // steam
        Relationship steamWithEmpty = new Relationship(empty, empty, steam); // sprays up
        steam.addRelationship(steamWithEmpty);
        Relationship steamWithSteam = new Relationship(steam, empty, steam); // vanishes
        steam.addRelationship(steamWithSteam);
        // clay
        Relationship clayWithEmpty = new Relationship(empty, empty, clay); // falls down
        clay.addRelationship(clayWithEmpty);
        Relationship clayWithWater = new Relationship(water, water, clay);// sinks through water
        clay.addRelationship(clayWithWater);
        
        // seed
        Relationship seedWithEmpty = new Relationship(empty, empty, seed); // falls down
        seed.addRelationship(seedWithEmpty);
        Relationship seedWithWater = new Relationship(water, water, seed); // falls down
        seed.addRelationship(seedWithWater);
        Relationship seedWithMud = new Relationship(mud, plant, seed); // seed turns into plant when it hits mud
        seed.addRelationship(seedWithMud); // this also means that it tunnels through the mud?
        // plant
        //Relationship plantWithEmpty = new Relationship(empty, plant, stem); 
            // coats plant on up, left, right sides with stem (curious!)
        Relationship plantWithEmpty = new Relationship(empty, stem, plant); // grows upward
        plant.addRelationship(plantWithEmpty);
        Relationship plantWithSeed = new Relationship(seed, stem, plant); // grows upward
        plant.addRelationship(plantWithSeed); // grows through seed too because it's hard to only plant one seed at a time
        // stem
            // stem should not grow itself (no empty, stem, stem)
        Relationship stemWithEmpty = new Relationship(empty, stem, branch); // empty branch stem, empty branch branch
        stem.addRelationship(stemWithEmpty);
        //branch
        Relationship branchWithEmpty = new Relationship(empty, branch, branch);
        branch.addRelationship(branchWithEmpty);
        
        // if this worked it would help branches to stop growing
        //SpecialRelationship branchToTip = new SpecialRelationship(branch, grownTip);
        //branch.addSpecialRelationship(branchToTip);
        
            
        // plant can grow stem, stem can grow branch
            // branch needs to grow out, not in
                // I would also like it to grow out a certain length (or range of lengths) 
                //      before growing up again
                    // it would be extra neat if the lower it was on the stem, the higher the upper limit 
                    //      of that length was
                    
        // set background to empty
        for (int i = 0; i < COLUMNS; i++){
            for (int j = 0; j < ROWS; j++){
                grid[j][i] = new Particle();
                grid[j][i].setName("Empty");
                grid[j][i].setColor(new Color (0,0,0));
            }
        }
        
        // keep this at the bottom
        display = new SandDisplay("Falling Sand", numRows, numCols, particles);
    }

    //called when the user clicks on a location using the given tool
    private void locationClicked(int row, int col, Particle tool)
    {
        grid[row][col] = tool.cloneParticle();
    }

    //copies each element of grid into the display
    public void updateDisplay()
    {
        Particle particle;
        
        for (int row = 0; row < ROWS; row++)
        {
            for (int column = 0; column < COLUMNS; column++)
            {
                particle = grid[row][column];
                display.setColor(row, column, particle.getColor());
            }
        }
    }
    
    //called repeatedly.
    //causes one random particle to maybe do something.
    public void step()
    {
        int randRow = (int) (Math.random() * ROWS);
        int randColumn = (int) (Math.random() * COLUMNS);
        Particle particle = grid[randRow][randColumn];
        Particle newParticle;
        SpecialParticle newSpecial;

        if (particle.isMoveable() == true){
            Movement direction = particle.getRandomMovement();
            int newRow = randRow + direction.getRowChange();
            int newColumn = randColumn + direction.getColumnChange();

            //Determine if the new location described by the Movement object is on the grid.
            if (0 <= newRow && newRow < ROWS && 0 <= newColumn && newColumn < COLUMNS){
                newParticle = grid[newRow][newColumn];
                if (particle.hasRelationshipWith(newParticle) == true){
                    Relationship betweenParticles = particle.getRelationshipWith(newParticle);
                    Particle newFirst = betweenParticles.getNewFirstParticle();
                    Particle newSecond = betweenParticles.getNewSecondParticle();
                    grid[randRow][randColumn] = newFirst;
                    grid[newRow][newColumn] = newSecond;
                }
            }
        }
        
        // problem!
        
        /*
        if (particle.getCanSpecial() == true){            
            // don't need to check if second particle is on the grid because it's in the same spot as the first
            newSpecial = (SpecialParticle)(grid[randRow][randColumn]); // hurrah for casting classes
            
            // regular particles don't have getSpecialRelationship
            // getRelationshipWith doesn't involve specialParticles because it works with regular ones
            // I'm stuck in a cycle here
            
            // ! make sure it HAS a relationship before grabbing it
            if (particle.hasSpecialRelationship(newSpecial) == true){ 
                SpecialRelationship particleAndSpecial = particle.getSpecialRelationship(newSpecial);
                // turns into other particle
                grid[randRow][randColumn] = particleAndSpecial.getNewSecondSpecial();
            }
        }
        */
    }

    //do not modify
    public void run()
    {
        while (true)
        {
            for (int i = 0; i < display.getSpeed(); i++)
            {
                step();
            }

            updateDisplay();
            display.repaint();
            display.pause(1);  //wait for redrawing and for mouse
            int[] mouseLoc = display.getMouseLocation();

            if (mouseLoc != null)  //test if mouse clicked
            {
                locationClicked(mouseLoc[0], mouseLoc[1], display.getTool());
            }
        }
    }
}