package objectorientedfallingsand;
import java.util.ArrayList;
import java.lang.Math;

public class SpecialParticle extends Particle{
    
    private int maxChance; 
    private int randomChance; //1 in x chance of something happening
        // could move this to SandLab?
    //private boolean special;
    // maybe special particles Do Not Move
    private ArrayList<SpecialRelationship> specialRelationships;
    
    public SpecialParticle(){
        maxChance = 10; // say, 1 in 10 chance
        randomChance = (int)(Math.random() * maxChance);
        //special = true;
    }
    
    public void setMaxChance(int inMaxChance){maxChance = inMaxChance;}
    public int getMaxChance(){return maxChance;}
    
    public void addSpecialRelationship(SpecialRelationship specialRelationship)
    {specialRelationships.add(specialRelationship);}
    
    public SpecialParticle cloneSpecial(){
        SpecialParticle clonedSpecial = new SpecialParticle();
        clonedSpecial.setName(name);
        clonedSpecial.setColor(color);
        clonedSpecial.setMaxChance(maxChance);
        clonedSpecial.specialRelationships = specialRelationships;
        return clonedSpecial;
    }
    
    // ex: if branch has relationship with grownTip
    public boolean hasSpecialRelationship(SpecialParticle newSecondSpecial){
        for (int i = 0; i < specialRelationships.size(); i++){ // looking through array list
            SpecialRelationship specialholder = specialRelationships.get(i);
            if (specialholder.getNewSecondSpecial().equals(newSecondSpecial)){ 
                // specialRelationship has no otherParticle
                return true;
            }
        }
        return false;
    }
    
    public SpecialRelationship getSpecialRelationship(SpecialParticle newSecondSpecial) {
        for (int i = 0; i < specialRelationships.size(); i++){ // looking through array list
            SpecialRelationship specialholder = specialRelationships.get(i);
            if (specialholder.getNewSecondSpecial().equals(newSecondSpecial)){ 
                return specialholder;
            }
        }
        return null;
    }
    
    // if random.chance == maxChance
        // call special relationship
            // branch turns into special growing tip
            // cloud turns into water
    
    /*
    Finally, let's add some inheritance to our program.  Create a new class that inherits from the Particle class.  This class should provide some additional functionality that is not present in the Particle class.  Some possibilities:

    An aging factor -
        a particle that changes color over time, similar to the Plip in HugLife.
    More complex relationships.  
        For example, maybe a Plant particle grows when a Sand and a Water particle are nearby.

    After you have programmed your new class, use this new class in your program.
    */
    /*
    public Particle(){
        name = "Placeholder";
        color = new Color(0, 0, 0);
        movements = new ArrayList<Movement>();
        relationships = new ArrayList<Relationship>();
    }
    */
    
    /*
    // if it's a branch particle I want it to stop growing after a certain length
    if (particle.getName().equals("Branch")){
    if (randomStop == 10){
        // how do I get it to turn into the ungrowing tip 10% of the time?
        Relationship betweenParticles = particle.getRelationshipWith(newParticle);
        Particle newFirst = betweenParticles.getNewFirstParticle();
        Particle newSecond = betweenParticles.getNewSecondParticle();
        grid[randRow][randColumn] = newFirst;
        grid[newRow][newColumn] = newSecond;
    }
    }
    */
}
