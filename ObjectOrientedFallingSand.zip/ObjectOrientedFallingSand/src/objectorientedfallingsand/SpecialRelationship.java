package objectorientedfallingsand;

// turn normal into special
public class SpecialRelationship {
    Particle newFirstParticle;
    SpecialParticle newSecondSpecial;
    
    // doesn't have to meet another particle, just has to change
    public SpecialRelationship(Particle inNewFirstParticle, SpecialParticle inNewSecondSpecial){
        
        newFirstParticle = inNewFirstParticle;
        newSecondSpecial = inNewSecondSpecial;
    }
    
    public Particle getNewFirstParticle(){return newFirstParticle.cloneParticle();}    
    public SpecialParticle getNewSecondSpecial(){return newSecondSpecial.cloneSpecial();}

}