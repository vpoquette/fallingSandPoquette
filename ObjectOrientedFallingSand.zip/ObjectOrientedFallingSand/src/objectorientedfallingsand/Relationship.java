package objectorientedfallingsand;

public class Relationship {
    Particle otherParticle;
    Particle newFirstParticle;
    Particle newSecondParticle;
    
    public Relationship(Particle inOtherParticle, Particle inNewFirstParticle, Particle inNewSecondParticle){
        otherParticle = inOtherParticle;
        newFirstParticle = inNewFirstParticle;
        newSecondParticle = inNewSecondParticle;
    }
    
    public Particle getOtherParticle(){return otherParticle;}
    public Particle getNewFirstParticle(){return newFirstParticle.cloneParticle();}
    public Particle getNewSecondParticle(){return newSecondParticle.cloneParticle();}
}