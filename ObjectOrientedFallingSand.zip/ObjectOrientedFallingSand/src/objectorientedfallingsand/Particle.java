package objectorientedfallingsand;
import java.awt.Color;
import java.util.ArrayList;

public class Particle implements Comparable
{
    // Fields go here.
    protected String name;
    protected Color color;
    protected ArrayList<Movement> movements;
    protected ArrayList<Relationship> relationships;
    protected boolean canVanish;
    protected boolean canSpecial;
    
    // Constructor(s) go here.
    public Particle(){
        name = "Placeholder";
        color = new Color(0, 0, 0);
        movements = new ArrayList<Movement>();
        relationships = new ArrayList<Relationship>();
        canVanish = false;
        canSpecial = false; // can have a special relationship
    }
    
    // Methods go here.
    public void setName(String inName){name = inName;}
    public String getName(){return name;}
    public void setColor(Color inColor){color = inColor;}
    public Color getColor(){return color;}
    public void setVanish(boolean inVanish){canVanish = inVanish;}
    public boolean getVanish(){return canVanish;}
    public void setCanSpecial(boolean inCanSpecial){canSpecial = inCanSpecial;}
    public boolean getCanSpecial(){return canSpecial;}
    
    public Particle cloneParticle(){
        Particle clonedParticle = new Particle();
        clonedParticle.setName(name);
        clonedParticle.setColor(color);
        clonedParticle.movements = movements;
        clonedParticle.relationships = relationships;
        return clonedParticle;
    }
    // movement methods
    public void addMovement(Movement movement){movements.add(movement);}
    
    public boolean isMoveable(){
        if (movements.size() > 0){return true;}
        else{return false;}
    }
    public Movement getRandomMovement(){
        if (movements.size() == 0){
            Movement stayStill = new Movement(0,0);
            return stayStill;}
        else{
            int randomMove = (int)(Math.random() * movements.size()); // random index
            Movement randomMovement = movements.get(randomMove); 
            return randomMovement;
        }
    }
    
    // relationship methods
    public void addRelationship(Relationship relationship){ relationships.add(relationship);}
    
    @Override
    public boolean equals(Object other){
        Particle objectParticle = (Particle)other;
        if (name.equals(objectParticle.getName()))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public boolean hasRelationshipWith(Particle otherParticle){
        for (int i = 0; i < relationships.size(); i++){ // looking through array list
            Relationship placeholder = relationships.get(i);
            if (placeholder.getOtherParticle().equals(otherParticle)){ // trying to compare Relationship with Particle?
                return true;
            }
        }
        return false;
    }
    
    public Relationship getRelationshipWith(Particle otherParticle) {
        for (int i = 0; i < relationships.size(); i++){ // looking through array list
            Relationship placeholder = relationships.get(i);
            if (placeholder.getOtherParticle().equals(otherParticle)){ // trying to compare Relationship with Particle?
                return placeholder;
            }
        }
        return null;
    }

    @Override
    public int compareTo(Object other) {
        Particle objectParticle = (Particle)other;
        int compare = this.name.compareTo(objectParticle.getName());  
        return compare;
        }
}
